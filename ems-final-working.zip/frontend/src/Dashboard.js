import {useEffect,useState} from "react";
import axios from "axios";

function Dashboard(){
 const [emps,setEmps]=useState([]);
 const [name,setName]=useState("");

 const load=()=>{
  axios.get("http://localhost:8080/employees")
   .then(res=>setEmps(res.data));
 };

 useEffect(()=>{load()},[]);

 const add=()=>{
  axios.post("http://localhost:8080/employees",{name})
   .then(()=>{setName("");load();});
 };

 return (
  <div className="container mt-5">
   <h2>EMS</h2>

   <input className="form-control mb-2"
    placeholder="Name"
    value={name}
    onChange={e=>setName(e.target.value)}
   />

   <button className="btn btn-success mb-3" onClick={add}>Add</button>

   <ul className="list-group">
    {emps.map(e=>(
     <li key={e.id} className="list-group-item">
      {e.name}
     </li>
    ))}
   </ul>
  </div>
 );
}

export default Dashboard;
