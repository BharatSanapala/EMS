package com.ems.controller;
import com.ems.entity.Employee;
import com.ems.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

 @Autowired
 private EmployeeRepository repo;

 @GetMapping
 public List<Employee> getAll(){
  return repo.findAll();
 }

 @PostMapping
 public Employee add(@RequestBody Employee e){
  return repo.save(e);
 }

 @DeleteMapping("/{id}")
 public void delete(@PathVariable Long id){
  repo.deleteById(id);
 }
}
