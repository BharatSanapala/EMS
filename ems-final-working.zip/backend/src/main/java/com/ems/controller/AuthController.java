package com.ems.controller;
import com.ems.entity.User;
import com.ems.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

 @Autowired
 private UserRepository repo;

 @PostMapping("/register")
 public User register(@RequestBody User user){
  user.setRole("USER");
  return repo.save(user);
 }
}
