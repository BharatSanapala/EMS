package com.ems.entity;
import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class Employee {
 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;
 private String name;
 private String department;
 private double salary;
}
